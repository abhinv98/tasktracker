const $ = (id) => document.getElementById(id);
let tab = null;
let settings = null;
let rec = null;
let ticker = null;

const show = (id) => ['view-form', 'view-rec', 'view-done'].forEach((v) => ($(v).hidden = v !== id));

const fmt = (ms) => {
  const s = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(s / 3600);
  const mm = Math.floor((s % 3600) / 60);
  const ss = String(s % 60).padStart(2, '0');
  return h ? `${h}:${String(mm).padStart(2, '0')}:${ss}` : `${mm}:${ss}`;
};

const micLabel = (m) => ({ on: 'On', 'needs-permission': 'Allow', failed: 'Off', starting: '...' })[m] || '-';

function chip(text, cls) {
  $('chip').className = `pill ${cls || ''}`;
  $('chip-text').textContent = text;
}

function render() {
  clearInterval(ticker);
  if (rec?.recording && !rec.stopping) {
    show('view-rec');
    chip('Recording', 'rec');
    $('rec-title').textContent = rec.title || '';
    $('rec-sub').textContent = 'Recording the meeting tab and your microphone.';
    $('stop').textContent = 'Stop and make notes';
    const tickNow = () => ($('elapsed').textContent = fmt(Date.now() - rec.startedAt));
    tickNow();
    ticker = setInterval(tickNow, 1000);
    $('uploaded').textContent = rec.uploaded ?? 0;
    $('pending').textContent = rec.pending ?? 0;
    $('mic').textContent = micLabel(rec.mic);
    $('rec-error').hidden = !rec.lastError;
    $('rec-error').textContent = rec.lastError || '';
    $('stop').disabled = false;
    return;
  }
  if (rec?.recording && rec.stopping) {
    show('view-rec');
    chip('Finishing', 'warn');
    $('rec-title').textContent = rec.title || '';
    $('elapsed').textContent = fmt((rec.stoppedAt || Date.now()) - rec.startedAt);
    $('mic').textContent = micLabel(rec.mic);
    $('rec-sub').textContent = `${rec.stopReason || 'Stopped'}. Uploading the last audio, then starting the notes.`;
    $('uploaded').textContent = rec.uploaded ?? 0;
    $('pending').textContent = rec.pending ?? 0;
    $('stop').disabled = true;
    $('stop').textContent = 'Finishing upload';
    return;
  }
  if (rec?.finishedAt) {
    show('view-done');
    const failed = rec.finalizeOk === false;
    chip(failed ? 'Needs attention' : 'Sent', failed ? 'warn' : 'ok');
    $('done-title').textContent = failed ? 'Recording stopped' : 'Sent for notes';
    $('done-sub').textContent = failed
      ? 'The server did not confirm. Open the review page and press "Process now" if it still says Recording.'
      : 'Transcribing now. Notes and the test emails follow in a few minutes.';
    $('done-error').hidden = !rec.lastError;
    $('done-error').textContent = rec.lastError || '';
    $('open-review').disabled = !rec.reviewUrl;
    return;
  }
  show('view-form');
  chip('Ready');
  const meeting = isMeetingUrl(tab?.url || '');
  $('not-meeting').hidden = meeting;
  $('no-token').hidden = !!settings.token;
  $('start').disabled = !meeting || !settings.token;
}

async function saveDraft() {
  await chrome.storage.local.set({
    draft: {
      title: $('title').value,
      titleTabId: tab?.id,
      attendees: $('attendees').value,
      language: $('language').value,
      keywords: $('keywords').value,
    },
  });
}

async function onStart() {
  const button = $('start');
  button.classList.add('busy');
  button.textContent = 'Starting...';
  $('form-error').textContent = '';
  try {
    const base = trimSlash(settings.backendUrl);
    const body = {
      title: $('title').value.trim() || cleanTitle(tab.title) || 'Meeting',
      hostName: settings.hostName,
      hostEmail: settings.hostEmail,
      attendees: parseAttendees($('attendees').value),
      language: $('language').value,
      keywords: $('keywords').value.split(',').map((k) => k.trim()).filter(Boolean),
      meetingUrl: tab.url,
    };
    let res;
    try {
      res = await fetch(`${base}/api/sessions`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${settings.token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
    } catch {
      throw new Error(`Cannot reach the server at ${base}. Is it running?`);
    }
    if (res.status === 401) throw new Error('The server rejected the API token. Check Settings.');
    if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || `Server error ${res.status}`);
    const { sessionId, reviewUrl } = await res.json();

    // Take the stream id inside this click and hand it straight on; the service worker retries if this fails.
    let streamId = null;
    try {
      streamId = await chrome.tabCapture.getMediaStreamId({ targetTabId: tab.id });
    } catch (e) {
      console.warn('getMediaStreamId from the popup failed, the service worker will try', e);
    }
    const r = await chrome.runtime.sendMessage({ target: 'background', type: 'start', tabId: tab.id, tabUrl: tab.url, streamId, sessionId, reviewUrl, title: body.title });
    if (!r?.ok) throw new Error(r?.error || 'Could not start the capture');
    await chrome.storage.local.set({ lastReviewUrl: reviewUrl });
  } catch (e) {
    $('form-error').textContent = e.message;
  } finally {
    button.classList.remove('busy');
    button.textContent = 'Start recording';
  }
}

/** Like hosted note-takers: the invite for this Meet link fills in who is coming, with their emails. */
async function prefillFromCalendar() {
  if (!settings.token || !isMeetingUrl(tab?.url || '') || rec?.recording) return;
  const hint = $('cal-hint');
  hint.hidden = false;
  hint.textContent = 'Checking your calendar for this meeting...';
  try {
    const base = trimSlash(settings.backendUrl);
    const q = new URLSearchParams({ url: tab.url, host: settings.hostEmail });
    const res = await fetch(`${base}/api/calendar?${q}`, {
      headers: { Authorization: `Bearer ${settings.token}` },
      signal: AbortSignal.timeout(12000),
    });
    const match = res.ok ? await res.json() : { found: false };
    if (!match.found) {
      hint.textContent = 'No calendar invite found for this link. Add attendees here or on the review page.';
      return;
    }
    const typed = parseAttendees($('attendees').value);
    const have = new Set(typed.map((a) => (a.email || a.name).toLowerCase()));
    const fresh = match.attendees.filter((a) => !have.has(a.email.toLowerCase()));
    if (fresh.length) {
      const lines = fresh.map((a) => `${a.name} <${a.email}>`);
      $('attendees').value = [$('attendees').value.trim(), ...lines].filter(Boolean).join('\n');
    }
    const title = $('title').value.trim();
    if (match.title && (!title || title === cleanTitle(tab.title) || /^[a-z]{3}-[a-z]{4}-[a-z]{3}$/.test(title))) {
      $('title').value = match.title;
    }
    hint.textContent = `From the calendar invite: ${match.attendees.length} guest${match.attendees.length === 1 ? '' : 's'} with email.`;
    saveDraft();
  } catch {
    hint.textContent = 'Could not reach the calendar just now. Attendees can be added on the review page.';
  }
}

async function init() {
  settings = await getSettings();
  [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  rec = (await chrome.storage.session.get('rec')).rec || null;

  const { draft, lastReviewUrl } = await chrome.storage.local.get(['draft', 'lastReviewUrl']);
  $('title').value = draft?.titleTabId === tab?.id && draft?.title ? draft.title : cleanTitle(tab?.title);
  $('attendees').value = draft?.attendees || '';
  $('language').value = draft?.language || 'auto';
  $('keywords').value = draft?.keywords || '';
  if (lastReviewUrl) {
    const u = new URL(lastReviewUrl);
    const key = u.searchParams.get('key');
    // Linked to the task tracker, the link already is that person's meetings page.
    $('all-meetings').href = key ? `${u.origin}/review?key=${encodeURIComponent(key)}` : lastReviewUrl;
    $('all-meetings').hidden = false;
  }

  for (const id of ['title', 'attendees', 'language', 'keywords']) $(id).addEventListener('input', saveDraft);
  prefillFromCalendar();
  $('start').addEventListener('click', onStart);
  $('stop').addEventListener('click', async () => {
    $('stop').disabled = true;
    await chrome.runtime.sendMessage({ target: 'background', type: 'stop' });
  });
  $('open-review').addEventListener('click', () => rec?.reviewUrl && chrome.tabs.create({ url: rec.reviewUrl }));
  $('new-meeting').addEventListener('click', async () => {
    await chrome.runtime.sendMessage({ target: 'background', type: 'reset' });
    $('title').value = cleanTitle(tab?.title);
  });
  $('all-meetings').addEventListener('click', (e) => {
    e.preventDefault();
    chrome.tabs.create({ url: $('all-meetings').href });
  });
  document.querySelectorAll('[data-open="options"]').forEach((a) =>
    a.addEventListener('click', (e) => {
      e.preventDefault();
      chrome.runtime.openOptionsPage();
    }),
  );
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'session' && changes.rec) {
      rec = changes.rec.newValue || null;
      render();
    }
    if (area === 'local' && changes.settings) getSettings().then((s) => ((settings = s), render()));
  });
  render();
}

init();
