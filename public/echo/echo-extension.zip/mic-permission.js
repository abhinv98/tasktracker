// Offscreen documents cannot show a permission prompt, so this visible page asks once for the
// extension's origin; the offscreen recorder then gets the microphone without a prompt.
const msg = document.getElementById('msg');

async function ask() {
  msg.textContent = 'Waiting for Chrome’s permission prompt...';
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    stream.getTracks().forEach((t) => t.stop());
    msg.textContent = 'Microphone allowed. Taking you back to the meeting.';
    await chrome.runtime.sendMessage({ target: 'background', type: 'mic-granted' }).catch(() => {});
    setTimeout(() => window.close(), 900);
  } catch (e) {
    msg.textContent =
      e.name === 'NotAllowedError'
        ? 'Chrome blocked the microphone. Click the icon at the right of the address bar, allow the microphone, then press the button again.'
        : `Could not open the microphone: ${e.message}`;
  }
}

document.getElementById('allow').addEventListener('click', ask);
ask();
