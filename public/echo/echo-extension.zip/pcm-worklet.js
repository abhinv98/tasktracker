// Mono Float32 frames at 16 kHz for the main thread. The context is created at 16 kHz; if Chrome
// ever hands back another rate, this resamples by linear interpolation so the output is still 16 kHz.
class PcmCapture extends AudioWorkletProcessor {
  constructor(options) {
    super();
    this.ratio = sampleRate / (options.processorOptions?.targetRate || 16000); // input samples per output sample
    this.t = 0; // position of the next output sample, in input samples, relative to the current block
    this.last = 0; // the previous block's final sample, for interpolation across blocks
    this.batch = new Float32Array(1600); // post every 100 ms of output
    this.n = 0;
    this.port.onmessage = (e) => {
      if (e.data === 'flush') {
        this.post();
        this.port.postMessage('flushed');
      }
    };
  }

  push(v) {
    this.batch[this.n++] = v;
    if (this.n === this.batch.length) this.post();
  }

  post() {
    if (!this.n) return;
    const out = this.batch.slice(0, this.n);
    this.port.postMessage(out, [out.buffer]);
    this.n = 0;
  }

  process(inputs) {
    // A track with no input still advances the clock: emit silence so each channel's timeline stays
    // aligned with the wall clock (the server lines the two channels up by their start times).
    const input = inputs[0]?.length && inputs[0][0] ? inputs[0] : [new Float32Array(128)];
    const len = input[0].length;
    const mono = new Float32Array(len);
    for (const ch of input) for (let i = 0; i < len; i++) mono[i] += ch[i];
    if (input.length > 1) for (let i = 0; i < len; i++) mono[i] /= input.length;

    if (this.ratio === 1) {
      for (let i = 0; i < len; i++) this.push(mono[i]);
      return true;
    }
    let t = this.t;
    while (t < len - 1) {
      const i = Math.floor(t);
      const f = t - i;
      const a = i < 0 ? this.last : mono[i];
      const b = mono[i + 1];
      this.push(a + (b - a) * f);
      t += this.ratio;
    }
    this.t = t - len;
    this.last = mono[len - 1];
    return true;
  }
}

registerProcessor('pcm-capture', PcmCapture);
