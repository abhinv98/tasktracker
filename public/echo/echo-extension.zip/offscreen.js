// Offscreen document: captures the meeting tab and the microphone as two separate 16 kHz mono PCM
// channels and uploads each every 10 seconds. Only chrome.runtime is available here.
let session = null;

const toBackground = (msg) => chrome.runtime.sendMessage({ target: 'background', ...msg }).catch(() => {});

function report() {
  if (!session) return;
  toBackground({
    type: 'status',
    sessionId: session.sessionId,
    uploaded: session.uploader.uploaded,
    pending: session.uploader.pending,
    lastError: session.uploader.lastError || session.micError,
    mic: session.micState,
  });
}

async function openChannel(name, stream) {
  const ctx = new AudioContext({ sampleRate: 16000 });
  // Chrome honours the requested rate; if it ever does not, the worklet resamples to 16 kHz.
  console.assert(ctx.sampleRate === 16000, `${name}: AudioContext at ${ctx.sampleRate} Hz, resampling in the worklet`);
  await ctx.audioWorklet.addModule(chrome.runtime.getURL('pcm-worklet.js'));
  const source = ctx.createMediaStreamSource(stream);
  const node = new AudioWorkletNode(ctx, 'pcm-capture', { processorOptions: { targetRate: 16000 } });
  const mute = ctx.createGain();
  mute.gain.value = 0; // keeps the graph pulled without playing anything
  source.connect(node).connect(mute).connect(ctx.destination);
  await ctx.resume().catch(() => {});
  const ch = { name, ctx, node, frames: [], seq: 0, t0: 0, onFlushed: null };
  node.port.onmessage = (e) => {
    if (e.data === 'flushed') return ch.onFlushed?.();
    if (!ch.t0) ch.t0 = Date.now() - Math.round(e.data.length / 16); // wall-clock time of the first sample
    ch.frames.push(e.data);
  };
  return ch;
}

/** Turn the buffered Float32 frames into one little-endian Int16 chunk and queue it. */
function cut(ch) {
  if (!ch.frames.length) return;
  const total = ch.frames.reduce((n, f) => n + f.length, 0);
  const pcm = new Int16Array(total);
  let o = 0;
  for (const f of ch.frames) {
    for (let i = 0; i < f.length; i++) {
      const s = Math.max(-1, Math.min(1, f[i]));
      pcm[o++] = s < 0 ? s * 0x8000 : s * 0x7fff;
    }
  }
  ch.frames = [];
  session.uploader.add(ch.name, ch.seq++, ch.t0, pcm.buffer);
}

async function startMic() {
  try {
    const micStream = await navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
    });
    session.micStream = micStream;
    session.channels.mic = await openChannel('mic', micStream);
    session.micState = 'on';
    session.micError = null;
  } catch (e) {
    // Offscreen documents cannot show a permission prompt; the service worker opens a page that can.
    session.micState = e.name === 'NotAllowedError' ? 'needs-permission' : 'failed';
    session.micError =
      e.name === 'NotAllowedError'
        ? 'Microphone permission needed. Allow it in the tab that just opened.'
        : `Microphone unavailable: ${e.message}`;
  }
  report();
}

async function start({ streamId, sessionId, backendUrl, token }) {
  if (session) throw new Error('A recording is already running');
  const tabStream = await navigator.mediaDevices.getUserMedia({
    audio: { mandatory: { chromeMediaSource: 'tab', chromeMediaSourceId: streamId } },
    video: false,
  });
  // Capturing a tab mutes it for the user, so play it back.
  const playback = new AudioContext();
  playback.createMediaStreamSource(tabStream).connect(playback.destination);
  await playback.resume().catch(() => {});

  session = {
    sessionId,
    tabStream,
    playback,
    channels: {},
    micState: 'starting',
    micError: null,
    stopping: false,
    uploader: new Uploader({ backendUrl, sessionId, token, onChange: report }),
  };
  session.channels.tab = await openChannel('tab', tabStream);
  tabStream.getAudioTracks()[0]?.addEventListener('ended', () => {
    if (session && !session.stopping) toBackground({ type: 'tab-ended' });
  });
  await startMic();
  session.timer = setInterval(() => Object.values(session.channels).forEach(cut), 10_000);
  return { ok: true, mic: session.micState };
}

async function retryMic() {
  if (!session || session.stopping) return { ok: false, error: 'not recording' };
  if (!session.channels.mic) await startMic();
  return { ok: session.micState === 'on', mic: session.micState };
}

async function finish() {
  const s = session;
  s.stopping = true;
  clearInterval(s.timer);
  // Collect each worklet's partial batch, then cut the last chunks.
  await Promise.all(
    Object.values(s.channels).map(
      (ch) =>
        new Promise((resolve) => {
          ch.onFlushed = resolve;
          ch.node.port.postMessage('flush');
          setTimeout(resolve, 500);
        }),
    ),
  );
  Object.values(s.channels).forEach(cut);
  for (const stream of [s.tabStream, s.micStream]) stream?.getTracks().forEach((t) => t.stop());
  await Promise.all([s.playback, ...Object.values(s.channels).map((c) => c.ctx)].map((c) => c.close().catch(() => {})));

  s.uploader.nudge();
  await s.uploader.drain(30_000);
  const pending = s.uploader.pending;
  s.uploader.close();

  let ok = false;
  let error = null;
  for (let attempt = 0; attempt < 4 && !ok; attempt++) {
    try {
      const r = await fetch(`${s.uploader.backendUrl}/api/sessions/${s.sessionId}/finalize`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${s.uploader.token}` },
      });
      ok = r.ok;
      if (!ok) error = `Finalize failed: HTTP ${r.status}`;
    } catch (e) {
      error = `Finalize failed: ${e.message}`;
    }
    if (!ok) await new Promise((r) => setTimeout(r, 1000 * 2 ** attempt));
  }
  report();
  session = null;
  toBackground({ type: 'finalized', ok, pending, error: ok ? null : error });
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.target !== 'offscreen') return false;
  if (msg.type === 'stop') {
    // Acknowledge at once; the outcome arrives as a separate 'finalized' message.
    if (session && !session.stopping) finish();
    else if (!session) toBackground({ type: 'finalized', ok: false, pending: 0, error: 'No capture was running. Use "Process now" on the review page.' });
    sendResponse({ ok: true });
    return false;
  }
  const run = { start, 'retry-mic': retryMic }[msg.type];
  if (!run) return false;
  run(msg).then(sendResponse, (e) => sendResponse({ ok: false, error: e.message || String(e) }));
  return true;
});
