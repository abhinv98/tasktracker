// Runs in every Google Meet tab. When you are in a call it records by itself, no click needed: the call's
// audio (what Meet plays through its <audio> elements, so never your own voice) as the 'tab' channel and
// your microphone as 'mic', both 16 kHz mono PCM in 10 s chunks, relayed through the service worker.
// A pill on the page says it is recording and can stop it.
(() => {
  const bg = (msg) => chrome.runtime.sendMessage({ target: 'background', ...msg }).catch((e) => ({ ok: false, error: e.message }));
  const icon = (name) => [...document.querySelectorAll('button i, button span')].some((el) => el.textContent === name);
  // The leave button: its label in English, or its icon in any language.
  const inCall = () => !!document.querySelector('button[aria-label*="Leave call" i]') || icon('call_end');
  // Meet's own microphone button: by its icon (the same in every language) or its English label.
  const micButton = () =>
    [...document.querySelectorAll('button[data-is-muted]')].find(
      (b) => /microphone/i.test(b.getAttribute('aria-label') || '') || [...b.querySelectorAll('i, span')].some((el) => /^mic(_off|_none)?$/.test(el.textContent.trim())),
    );
  // Muted in Meet means not said to the meeting, so it must not reach the notes either. If the button
  // cannot be found (Meet changed its page), record nothing from the microphone rather than guess.
  const micMuted = () => {
    const b = micButton();
    return b ? b.dataset.isMuted === 'true' : true;
  };

  let rec = null; // the running recording
  let starting = false;
  let declined = false; // stopped by hand, or auto-record is off: not again in this call
  let retryAt = 0;
  let outSince = 0;

  /* ---------- the pill ---------- */
  let pill = null;
  function showPill(text, { stop = false, fade = 0 } = {}) {
    pill?.remove();
    pill = document.createElement('div');
    pill.setAttribute('role', 'status');
    pill.style.cssText =
      'position:fixed;top:12px;left:12px;z-index:2147483647;display:flex;align-items:center;gap:8px;padding:6px 8px 6px 12px;' +
      'border-radius:999px;background:#111;color:#fff;font:500 13px/18px system-ui,sans-serif;box-shadow:0 2px 10px rgba(0,0,0,.35)';
    const dot = document.createElement('span');
    dot.style.cssText = `width:8px;height:8px;border-radius:50%;background:${stop ? '#ec7202' : '#40e0a6'};flex:none`;
    const label = document.createElement('span');
    label.textContent = text;
    pill.append(dot, label);
    if (stop) {
      const b = document.createElement('button');
      b.type = 'button';
      b.textContent = 'Stop';
      b.style.cssText = 'border:0;border-radius:999px;padding:3px 10px;background:#fff;color:#111;font:inherit;cursor:pointer';
      b.addEventListener('click', () => finish('Stopped on the meeting page', true));
      pill.append(b);
    } else {
      pill.style.paddingRight = '12px';
    }
    document.documentElement.append(pill);
    const mine = pill;
    if (fade) setTimeout(() => mine.remove(), fade); // only this pill: a newer one may be showing by then
  }

  /* ---------- capture ---------- */
  // ponytail: ScriptProcessorNode (main thread, deprecated) because Meet's CSP may refuse a worklet module;
  // move to an AudioWorklet if chunks ever show gaps.
  function openChannel(ctx, name, silent) {
    const ch = { name, frames: [], seq: 0, t0: 0 };
    ch.node = ctx.createScriptProcessor(4096, 1, 1);
    ch.node.onaudioprocess = (e) => {
      const f = e.inputBuffer.getChannelData(0);
      if (!ch.t0) ch.t0 = Date.now() - Math.round(f.length / 16);
      // A muted stretch is kept as silence so both channels stay on the same clock.
      ch.frames.push(silent?.() ? new Float32Array(f.length) : new Float32Array(f));
    };
    const mute = ctx.createGain();
    mute.gain.value = 0;
    ch.node.connect(mute).connect(ctx.destination);
    return ch;
  }

  function cut(ch) {
    if (!ch.frames.length) return;
    const pcm = new Int16Array(ch.frames.reduce((n, f) => n + f.length, 0));
    let o = 0;
    for (const f of ch.frames) {
      for (let i = 0; i < f.length; i++) {
        const s = Math.max(-1, Math.min(1, f[i]));
        pcm[o++] = s < 0 ? s * 0x8000 : s * 0x7fff;
      }
    }
    ch.frames = [];
    rec.uploader.add(ch.name, ch.seq++, ch.t0, pcm.buffer);
  }

  const toB64 = (buffer) => {
    const bytes = new Uint8Array(buffer);
    let bin = '';
    for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
    return btoa(bin);
  };

  // Participant tiles carry the display name in leaf .notranslate elements (same reading as background.js).
  function readNames() {
    const out = new Set();
    for (const tile of document.querySelectorAll('[data-participant-id]')) {
      for (const el of tile.querySelectorAll('.notranslate')) {
        if (el.children.length) continue;
        const t = (el.textContent || '').replace(/\s+/g, ' ').trim().replace(/\s*\((you|presentation|presenting)\)$/i, '');
        if (t.length < 2 || t.length > 60 || /^[a-z_]+$/.test(t) || /^[a-z]{3}-[a-z]{4}-[a-z]{3}$/.test(t) || /^you$/i.test(t)) continue;
        out.add(t);
      }
    }
    return [...out].slice(0, 50);
  }

  async function start() {
    starting = true;
    let sessionId = null;
    try {
      const code = location.pathname.match(/[a-z]{3}-[a-z]{4}-[a-z]{3}/)?.[0] || 'Meeting';
      const res = await bg({ type: 'auto-start', title: cleanTitle(document.title) || code, meetingUrl: location.origin + location.pathname });
      if (!res?.ok) {
        // Not linked, switched off or already recording another call: stay quiet. A server hiccup: try again.
        if (res?.retry) retryAt = Date.now() + 30000;
        else declined = true;
        if (res?.relink) showPill('Echo needs linking again. Open your task tracker profile.', { fade: 15000 });
        return;
      }
      sessionId = res.sessionId;
      const ctx = new AudioContext({ sampleRate: 16000 });
      const r = { sessionId: res.sessionId, ctx, channels: {}, seenTracks: new WeakSet(), names: new Set(), stopping: false, micStream: null };
      r.uploader = new Uploader({
        backendUrl: 'https://echo',
        sessionId: res.sessionId,
        token: '', // the service worker adds the real one
        onChange: () => bg({ type: 'status', sessionId: r.sessionId, uploaded: r.uploader.uploaded, pending: r.uploader.pending, lastError: r.uploader.lastError, mic: r.micStream ? 'on' : 'failed' }),
        fetchImpl: async (url, init) => {
          const u = new URL(url);
          const out = await bg({ type: 'api', path: u.pathname + u.search, method: 'POST', b64: toB64(init.body) });
          if (typeof out?.status !== 'number') throw new Error(out?.error || 'the extension is not answering');
          return out;
        },
      });
      r.channels.tab = openChannel(ctx, 'tab');
      // Meet already holds the microphone permission for this site; never raise a prompt of our own.
      try {
        const perm = await navigator.permissions.query({ name: 'microphone' });
        if (perm.state === 'granted') {
          r.micStream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true } });
          r.channels.mic = openChannel(ctx, 'mic', micMuted);
          ctx.createMediaStreamSource(r.micStream).connect(r.channels.mic.node);
        }
      } catch {}
      rec = r;
      const attach = () => {
        for (const el of document.querySelectorAll('audio')) {
          for (const track of el.srcObject?.getAudioTracks?.() ?? []) {
            if (r.seenTracks.has(track)) continue;
            r.seenTracks.add(track);
            ctx.createMediaStreamSource(new MediaStream([track])).connect(r.channels.tab.node);
          }
        }
        if (ctx.state !== 'running') ctx.resume().catch(() => {});
      };
      attach();
      r.timers = [
        setInterval(attach, 2000),
        setInterval(() => Object.values(r.channels).forEach(cut), 10000),
        setInterval(() => {
          const fresh = readNames().filter((n) => !r.names.has(n));
          if (!fresh.length) return;
          fresh.forEach((n) => r.names.add(n));
          bg({ type: 'api', path: `/api/sessions/${r.sessionId}/participants`, method: 'POST', json: { names: fresh } });
        }, 20000),
      ];
      showPill(r.channels.mic && !micButton() ? 'Echo is recording the call, but not your microphone' : 'Echo is recording for notes', { stop: true });
    } catch (e) {
      // The session exists on the server but nothing will record into it: close it instead of leaving it open.
      declined = true;
      rec = null;
      if (sessionId) {
        const done = await bg({ type: 'api', path: `/api/sessions/${sessionId}/finalize`, method: 'POST' });
        await bg({ type: 'finalized', ok: !!done?.ok, pending: 0, error: `Echo could not start recording: ${e.message}` });
      }
      showPill('Echo could not start recording', { fade: 8000 });
    } finally {
      starting = false;
    }
  }

  async function finish(reason, byHand = false) {
    const r = rec;
    if (!r || r.stopping) return;
    r.stopping = true;
    if (byHand) declined = true;
    r.timers.forEach(clearInterval);
    Object.values(r.channels).forEach(cut);
    r.micStream?.getTracks().forEach((t) => t.stop());
    r.ctx.close().catch(() => {});
    showPill('Echo is sending the last audio');
    r.uploader.nudge();
    await r.uploader.drain(30000);
    const pending = r.uploader.pending;
    r.uploader.close();
    let done = null;
    for (let attempt = 0; attempt < 4 && !done?.ok; attempt++) {
      done = await bg({ type: 'api', path: `/api/sessions/${r.sessionId}/finalize`, method: 'POST' });
      if (!done?.ok) await new Promise((res) => setTimeout(res, 1000 * 2 ** attempt));
    }
    await bg({ type: 'finalized', ok: !!done?.ok, pending, error: done?.ok ? null : `${reason}. Finalize failed: ${done?.error || `HTTP ${done?.status}`}` });
    rec = null;
    showPill(done?.ok ? 'Echo is writing the notes' : 'Echo could not finish this recording', { fade: 8000 });
  }

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg?.target !== 'meet-auto') return false;
    if (msg.type === 'stop') {
      sendResponse({ ok: !!rec });
      finish('Stopped from the popup', true);
    }
    return false;
  });

  setInterval(() => {
    const here = inCall();
    if (rec) {
      // Meet redraws its controls now and then; leave only once the call has really been gone for a bit.
      if (here) outSince = 0;
      else if (!outSince) outSince = Date.now();
      else if (Date.now() - outSince > 6000) finish('You left the meeting');
      return;
    }
    // Stopped by hand stays stopped until the call has really ended (same grace as above), so a redraw
    // of Meet's controls cannot start a recording nobody asked for.
    if (here) {
      outSince = 0;
      if (!starting && !declined && Date.now() >= retryAt) start();
    } else if (!outSince) outSince = Date.now();
    else if (Date.now() - outSince > 6000) declined = false;
  }, 2000);
})();
