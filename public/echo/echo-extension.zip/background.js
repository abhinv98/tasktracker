// Service worker: owns the recording state, the badge, the offscreen document and auto-stop.
importScripts('shared.js');

const getState = async () => (await chrome.storage.session.get('rec')).rec || null;

// Status, stop and finalize messages arrive concurrently; serialise every read-modify-write so a late
// status update can never resurrect a finished recording.
let lock = Promise.resolve();
/** patch: an object to merge, null to clear, or a function of the current state returning either
 *  (undefined means no change); a function runs inside the lock, so it sees the latest state. */
function setState(patch) {
  const run = lock.then(async () => {
    const current = await getState();
    const p = typeof patch === 'function' ? patch(current) : patch;
    if (p === undefined) return current;
    const next = p === null ? null : { ...(current || {}), ...p };
    await chrome.storage.session.set({ rec: next });
    return next;
  });
  lock = run.catch(() => {});
  return run;
}

let creating = null;
async function ensureOffscreen() {
  const existing = await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'] });
  if (existing.length) return;
  creating ??= chrome.offscreen.createDocument({
    url: 'offscreen.html',
    reasons: ['USER_MEDIA'],
    justification: 'Record meeting tab audio and microphone',
  });
  try {
    await creating;
  } finally {
    creating = null;
  }
}

async function closeOffscreen() {
  const existing = await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'] });
  if (existing.length) await chrome.offscreen.closeDocument().catch(() => {});
}

const toOffscreen = (msg) => chrome.runtime.sendMessage({ target: 'offscreen', ...msg });

async function setBadge(text, color = '#c4242a') {
  await chrome.action.setBadgeText({ text });
  if (text) await chrome.action.setBadgeBackgroundColor({ color });
}

async function start({ tabId, tabUrl, streamId, sessionId, reviewUrl, title }) {
  const current = await getState();
  if (current?.recording) throw new Error('Already recording. Stop the current meeting first.');
  const settings = await getSettings();
  // Chrome's own sample takes the stream id here, after the action click; the popup tries first.
  if (!streamId) streamId = await chrome.tabCapture.getMediaStreamId({ targetTabId: tabId });
  await ensureOffscreen();
  const res = await toOffscreen({
    type: 'start',
    streamId,
    sessionId,
    backendUrl: trimSlash(settings.backendUrl),
    token: settings.token,
  });
  if (!res?.ok) {
    await closeOffscreen();
    throw new Error(res?.error || 'Could not start the capture');
  }
  await setState(null);
  await setState({
    recording: true,
    stopping: false,
    sessionId,
    reviewUrl,
    title,
    tabId,
    tabUrl,
    startedAt: Date.now(),
    uploaded: 0,
    pending: 0,
    lastError: null,
    mic: res.mic,
  });
  await setBadge('REC');
  if (res.mic === 'needs-permission') await askForMic();
  return { ok: true, mic: res.mic };
}

async function askForMic() {
  await chrome.tabs.create({ url: chrome.runtime.getURL('mic-permission.html'), active: true });
}

/** One place where the extension talks to the server, with the stored token. */
async function api(path, { method = 'GET', json, b64 } = {}) {
  const s = await getSettings();
  const res = await fetch(`${trimSlash(s.backendUrl)}${path}`, {
    method,
    headers: { Authorization: `Bearer ${s.token}`, ...(json ? { 'Content-Type': 'application/json' } : b64 ? { 'Content-Type': 'application/octet-stream' } : {}) },
    body: json ? JSON.stringify(json) : b64 ? Uint8Array.from(atob(b64), (c) => c.charCodeAt(0)) : undefined,
    signal: AbortSignal.timeout(20000),
  });
  return { ok: res.ok, status: res.status, data: await res.json().catch(() => null) };
}

/** Google Meet page details from the server (kept for 6 hours), so a change to Meet's page is fixed
 *  there instead of with a new extension. On any failure the caller keeps its built-in values. */
async function extensionConfig() {
  const { extConfig } = await chrome.storage.local.get('extConfig');
  if (extConfig && Date.now() - extConfig.at < 6 * 3600 * 1000) return { ok: true, ...extConfig.data };
  try {
    const res = await api('/api/extension-config');
    if (res.ok && res.data?.meet) {
      await chrome.storage.local.set({ extConfig: { at: Date.now(), data: res.data } });
      return { ok: true, ...res.data };
    }
  } catch {}
  return extConfig ? { ok: true, ...extConfig.data } : { ok: false };
}

/** A Meet tab says its call has begun (meet-auto.js). Creates the session; the tab then records itself. */
async function autoStart({ title, meetingUrl }, tab) {
  const s = await getSettings();
  if (!s.token || !s.autoRecord || !tab?.id) return { ok: false };
  const st = await getState();
  if (st?.recording) {
    if (!(st.auto && st.tabId === tab.id)) return { ok: false };
    // The same tab asking again means its page was reloaded or replaced mid-call and the old recording
    // died with it. Close that one (a new session, since chunk numbers restart) and carry on.
    await api(`/api/sessions/${st.sessionId}/finalize`, { method: 'POST' }).catch(() => null);
    // That recording is over whatever the server says next (it may answer "a teammate has this call"
    // or fail): forget it, or the badge keeps saying REC and other Meet tabs are refused.
    await setState(null);
    await setBadge('');
  }
  let res;
  try {
    // canShare: this extension understands "a teammate is already recording this call".
    res = await api('/api/sessions', { method: 'POST', json: { title, hostName: s.hostName, hostEmail: s.hostEmail, attendees: [], meetingUrl, canShare: true } });
  } catch (e) {
    return { ok: false, retry: true, error: e.message };
  }
  if (!res.ok) return { ok: false, retry: res.status >= 500, relink: res.status === 401, error: res.data?.error };
  // One recording per meeting: a teammate's Echo has this call, so this one stays quiet. The tab asks
  // again every 30 s and starts recording itself if that recording has ended while the call goes on.
  if (res.data?.covered) return { ok: false, covered: true, by: res.data.by || 'A teammate' };
  await setState(null);
  await setState({
    recording: true,
    stopping: false,
    auto: true,
    sessionId: res.data.sessionId,
    reviewUrl: res.data.reviewUrl,
    title,
    tabId: tab.id,
    tabUrl: meetingUrl,
    startedAt: Date.now(),
    uploaded: 0,
    pending: 0,
    lastError: null,
    mic: 'starting',
  });
  await setBadge('REC');
  await chrome.storage.local.set({ lastReviewUrl: res.data.reviewUrl });
  return { ok: true, sessionId: res.data.sessionId };
}

async function stop(reason, tabGone = false) {
  const st = await getState();
  // An auto recording whose tab has closed must still be finalized, even if Stop was already pressed.
  if (!st?.recording || (st.stopping && !(st.auto && tabGone))) return { ok: true };
  await setState({ stopping: true, stopReason: reason, stoppedAt: Date.now() });
  await setBadge('...', '#5d5f60');
  if (st.auto) {
    // The Meet tab uploads its last audio and finalizes. If the tab is gone, finalize what the server has.
    // ponytail: closing the tab loses the last seconds still in the page (at most one 10 s chunk).
    const told = tabGone ? null : await chrome.tabs.sendMessage(st.tabId, { target: 'meet-auto', type: 'stop' }).catch(() => null);
    if (!told?.ok) {
      const done = await api(`/api/sessions/${st.sessionId}/finalize`, { method: 'POST' }).catch((e) => ({ ok: false, status: e.message }));
      await setState({ recording: false, stopping: false, finishedAt: Date.now(), finalizeOk: done.ok, lastError: done.ok ? null : `Finalize failed: ${done.status}` });
      await setBadge('');
    }
    return { ok: true };
  }
  // The offscreen document drains the queue, finalizes and then reports 'finalized'.
  toOffscreen({ type: 'stop' }).catch(async (e) => {
    await setState({ recording: false, stopping: false, finishedAt: Date.now(), finalizeOk: false, lastError: `Stop failed: ${e.message}` });
    await setBadge('');
  });
  return { ok: true };
}

async function handle(msg, sender) {
  switch (msg.type) {
    case 'start':
      return start(msg);
    case 'auto-start':
      return autoStart(msg, sender.tab);
    case 'config':
      return extensionConfig();
    case 'api':
      // Content scripts reach the server through here; only a recording's own routes.
      if (!/^\/api\/sessions\/[a-z0-9-]+\/(audio|participants|finalize)(\?|$)/.test(msg.path || '')) return { ok: false, error: 'not allowed' };
      return api(msg.path, msg);
    case 'stop':
      return stop('Stopped from the popup');
    case 'status':
      await setState((st) =>
        st?.sessionId === msg.sessionId && st.recording && !st.finishedAt
          ? { uploaded: msg.uploaded, pending: msg.pending, lastError: msg.lastError || null, mic: msg.mic }
          : undefined,
      );
      getState().then(scanNames);
      return { ok: true };
    case 'mic-needed':
      await askForMic();
      return { ok: true };
    case 'mic-granted': {
      const st = await getState();
      if (st?.recording && !st.stopping) {
        await toOffscreen({ type: 'retry-mic' }).catch(() => {});
        if (st.tabId) await chrome.tabs.update(st.tabId, { active: true }).catch(() => {});
      }
      return { ok: true };
    }
    case 'tab-ended':
      return stop('The meeting tab stopped sharing audio');
    case 'finalized': {
      await setState({
        recording: false,
        stopping: false,
        finishedAt: Date.now(),
        finalizeOk: !!msg.ok,
        pending: msg.pending || 0,
        lastError: msg.error || (msg.pending ? `${msg.pending} chunks could not be uploaded before finalizing` : null),
      });
      await setBadge('');
      await closeOffscreen();
      return { ok: true };
    }
    case 'reset':
      await setState(null);
      return { ok: true };
    default:
      return { ok: false, error: `unknown message ${msg.type}` };
  }
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.target !== 'background') return false;
  handle(msg, _sender).then(sendResponse, (e) => sendResponse({ ok: false, error: e.message || String(e) }));
  return true;
});

/* Names off the Meet window, every 20 s while recording: people who joined without an invite. They go to the
   review page as suggestions only. Runs under the activeTab grant from pressing Start on that tab. */
let lastScan = 0;
async function scanNames(st) {
  if (!st?.recording || st.auto || st.stopping || !st.tabId || !/^https:\/\/meet\.google\.com\//.test(st.tabUrl || '')) return;
  if (Date.now() - lastScan < 20000) return;
  lastScan = Date.now();
  try {
    const [res] = await chrome.scripting.executeScript({ target: { tabId: st.tabId }, func: readMeetNames });
    const names = (res?.result || []).filter((n) => !(st.names || []).includes(n));
    if (!names.length) return;
    const s = await getSettings();
    const r = await fetch(`${trimSlash(s.backendUrl)}/api/sessions/${st.sessionId}/participants`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${s.token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ names }),
    });
    if (r.ok) await setState((cur) => (cur?.sessionId === st.sessionId ? { names: [...(cur.names || []), ...names] } : undefined));
  } catch (e) {
    console.warn('Echo: reading names from the Meet window failed', e);
  }
}

/** Runs inside the Meet tab. Participant tiles carry their display name in leaf .notranslate elements. */
function readMeetNames() {
  const out = new Set();
  for (const tile of document.querySelectorAll('[data-participant-id]')) {
    for (const el of tile.querySelectorAll('.notranslate')) {
      if (el.children.length) continue;
      const t = (el.textContent || '').replace(/\s+/g, ' ').trim().replace(/\s*\((you|presentation|presenting)\)$/i, '');
      // Skip icon ligatures (mic_off, more_vert), meeting codes and "You".
      if (t.length < 2 || t.length > 60 || /^[a-z_]+$/.test(t) || /^[a-z]{3}-[a-z]{4}-[a-z]{3}$/.test(t) || /^you$/i.test(t)) continue;
      out.add(t);
    }
  }
  return [...out].slice(0, 50);
}

// Auto-stop when the captured tab closes or leaves the meeting.
chrome.tabs.onRemoved.addListener(async (tabId) => {
  const st = await getState();
  if (st?.recording && st.tabId === tabId) await stop('The meeting tab was closed', true);
});
chrome.tabs.onUpdated.addListener(async (tabId, info) => {
  if (!info.url) return;
  const st = await getState();
  if (st?.recording && st.tabId === tabId && !isMeetingUrl(info.url)) await stop('The meeting tab left the meeting');
});

// A browser restart loses the capture; do not leave a stale REC badge behind.
chrome.runtime.onStartup.addListener(() => setBadge(''));
