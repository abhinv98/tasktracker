const $ = (id) => document.getElementById(id);
const FIELDS = ['backendUrl', 'token', 'hostName', 'hostEmail'];

function say(text, cls = '') {
  $('status').textContent = text;
  $('status').className = cls;
}

async function save() {
  if (!$('form').reportValidity()) return false;
  const settings = Object.fromEntries(FIELDS.map((f) => [f, $(f).value.trim()]));
  settings.autoRecord = $('autoRecord').checked;
  settings.backendUrl = trimSlash(settings.backendUrl);
  await chrome.storage.local.set({ settings });
  return settings;
}

async function test() {
  const s = await save();
  if (!s) return;
  say('Testing...');
  try {
    const res = await fetch(`${s.backendUrl}/api/ping`, { headers: { Authorization: `Bearer ${s.token}` } });
    if (res.status === 401) return say('Reached the server, but it rejected the token.', 'bad-text');
    if (!res.ok) return say(`The server answered ${res.status}.`, 'bad-text');
    const info = await res.json();
    say(`Connected. ${info.sendMode === 'test' ? `Test mode: every email goes to ${info.testInbox}.` : 'Real send mode.'}`, 'ok-text');
  } catch {
    say(`Cannot reach ${s.backendUrl}. Is the server running?`, 'bad-text');
  }
}

async function micState() {
  try {
    const p = await navigator.permissions.query({ name: 'microphone' });
    const text = { granted: 'Allowed. Your side of the meeting will be recorded.', denied: 'Blocked. Allow it in Chrome settings for this extension.', prompt: 'Not allowed yet. Allow it now so the first meeting starts cleanly.' };
    $('mic-state').textContent = text[p.state] || p.state;
    $('mic').hidden = p.state === 'granted';
    p.onchange = micState;
  } catch {
    $('mic-state').textContent = 'Unknown';
  }
}

(async () => {
  const s = await getSettings();
  for (const f of FIELDS) $(f).value = s[f] || '';
  $('autoRecord').checked = !!s.autoRecord;
  $('form').addEventListener('submit', async (e) => {
    e.preventDefault();
    if (await save()) say('Saved.', 'ok-text');
  });
  $('test').addEventListener('click', test);
  $('mic').addEventListener('click', () => chrome.tabs.create({ url: chrome.runtime.getURL('mic-permission.html') }));
  micState();
})();
