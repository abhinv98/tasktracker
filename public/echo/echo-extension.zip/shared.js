// Shared by the popup, the options page and the service worker (importScripts).
const DEFAULTS = {
  backendUrl: 'https://echo-production-64df.up.railway.app',
  token: '',
  hostName: 'Abhinav',
  hostEmail: '98abrai@gmail.com',
  autoRecord: true, // record a Google Meet call as soon as you are in it (meet-auto.js)
};

async function getSettings() {
  const { settings } = await chrome.storage.local.get('settings');
  return { ...DEFAULTS, ...(settings || {}) };
}

/** Google Meet, or Zoom's web client. The Zoom desktop app cannot be captured. */
function isMeetingUrl(url) {
  try {
    const u = new URL(url);
    if (u.protocol !== 'https:') return false;
    if (u.hostname === 'meet.google.com') return true;
    return (u.hostname === 'app.zoom.us' || u.hostname.endsWith('.zoom.us')) && u.pathname.startsWith('/wc');
  } catch {
    return false;
  }
}

const trimSlash = (s) => String(s || '').trim().replace(/\/+$/, '');

function cleanTitle(t = '') {
  return t.replace(/^Meet\s*[-–]\s*/i, '').replace(/\s*[-–|]\s*(Google Meet|Zoom)$/i, '').trim();
}

/** "Name <email>", "Name, email" or a bare email; a name is derived from the email when missing. */
function parseAttendees(text) {
  const fromEmail = (e) =>
    e.split('@')[0].split(/[._-]+/).filter(Boolean).map((w) => w[0].toUpperCase() + w.slice(1)).join(' ');
  return text
    .split('\n')
    .map((l) => l.trim())
    .filter(Boolean)
    .map((line) => {
      let m = line.match(/^(.*?)\s*<\s*([^<>\s]+@[^<>\s]+)\s*>$/);
      if (m) return { name: m[1].trim() || fromEmail(m[2]), email: m[2] };
      m = line.match(/^(.*?)\s*,\s*([^,\s]+@[^,\s]+)$/);
      if (m) return { name: m[1].trim() || fromEmail(m[2]), email: m[2] };
      if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(line)) return { name: fromEmail(line), email: line };
      return { name: line };
    });
}
