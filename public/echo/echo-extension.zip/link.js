// Runs on the task tracker only. Its profile page links this browser's Echo to the signed-in person by
// handing over their personal key; this script stores it and tells the page what is installed and linked.
(() => {
  const say = async () => {
    const { settings } = await chrome.storage.local.get('settings');
    const linked = (settings?.token || '').startsWith('ek1.');
    window.postMessage(
      { source: 'echo-extension', type: 'hello', version: chrome.runtime.getManifest().version, linkedEmail: linked ? settings.hostEmail : null },
      location.origin,
    );
  };
  window.addEventListener('message', async (e) => {
    const d = e.data;
    if (e.source !== window || e.origin !== location.origin || d?.source !== 'tasktracker') return;
    if (d.type === 'link' && typeof d.key === 'string' && d.key.startsWith('ek1.') && typeof d.name === 'string' && typeof d.email === 'string') {
      const { settings } = await chrome.storage.local.get('settings');
      await chrome.storage.local.set({ settings: { ...(settings || {}), token: d.key, hostName: d.name, hostEmail: d.email } });
    } else if (d.type !== 'ping') return;
    say();
  });
  say();
})();
