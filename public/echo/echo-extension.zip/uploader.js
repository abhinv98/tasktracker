// Ordered upload queue with retry and backoff. A failed chunk stays at the head of the queue until it
// lands; nothing is dropped silently. Plain script so the offscreen page and the Node test share it.
class Uploader {
  constructor({ backendUrl, sessionId, token, onChange = () => {}, fetchImpl, baseDelay = 1000, maxDelay = 15000 }) {
    Object.assign(this, { backendUrl, sessionId, token, onChange, baseDelay, maxDelay });
    this.fetch = fetchImpl || ((...a) => fetch(...a));
    this.queue = [];
    this.uploaded = 0;
    this.rejected = 0;
    this.lastError = null;
    this.lastRejection = null;
    this.delay = 0;
    this.running = false;
    this.closed = false;
    this.timer = null;
    this.wake = null;
  }

  get pending() {
    return this.queue.length;
  }

  add(channel, seq, t0, body) {
    this.queue.push({ channel, seq, t0, body });
    this.onChange();
    this.pump();
  }

  /** Retry now instead of waiting out the backoff (used when stopping). */
  nudge() {
    this.delay = 0;
    clearTimeout(this.timer);
    this.wake?.();
  }

  close() {
    this.closed = true;
    this.nudge();
  }

  wait(ms) {
    return new Promise((resolve) => {
      this.wake = resolve;
      this.timer = setTimeout(resolve, ms);
    });
  }

  async pump() {
    if (this.running) return;
    this.running = true;
    try {
      while (this.queue.length && !this.closed) {
        const item = this.queue[0];
        const url = `${this.backendUrl}/api/sessions/${this.sessionId}/audio?channel=${item.channel}&seq=${item.seq}&t0=${item.t0}`;
        let res = null;
        let error = null;
        try {
          res = await this.fetch(url, {
            method: 'POST',
            headers: { Authorization: `Bearer ${this.token}`, 'Content-Type': 'application/octet-stream' },
            body: item.body,
            signal: AbortSignal.timeout(20000),
          });
        } catch (e) {
          error = e;
        }
        if (res?.ok) {
          this.queue.shift();
          this.uploaded++;
          this.delay = 0;
          this.lastError = this.lastRejection || null; // a refused chunk stays reported
          this.onChange();
          continue;
        }
        if (res && res.status >= 400 && res.status < 500 && res.status !== 408 && res.status !== 429) {
          // A permanent refusal (finalized, unknown session, bad token, too large): retrying cannot land
          // it and would block every chunk behind it. Drop it and say so, never silently.
          this.queue.shift();
          this.rejected++;
          this.lastError = this.lastRejection =
            res.status === 409
              ? `${item.channel} chunk ${item.seq} arrived after the meeting was finalized`
              : res.status === 401
                ? `The server rejected the API token, so ${this.rejected} chunk(s) could not be saved. Check Settings.`
                : `The server refused ${item.channel} chunk ${item.seq} (HTTP ${res.status}); ${this.rejected} chunk(s) lost so far.`;
          this.onChange();
          continue;
        }
        this.lastError = `Upload failed (${error ? error.message : `HTTP ${res.status}`}). Retrying; ${this.queue.length} chunks waiting.`;
        this.delay = Math.min(this.maxDelay, this.delay ? this.delay * 2 : this.baseDelay);
        this.onChange();
        await this.wait(this.delay);
      }
    } finally {
      this.running = false;
    }
  }

  /** Resolves true once everything is uploaded, false after timeoutMs. */
  async drain(timeoutMs) {
    const end = Date.now() + timeoutMs;
    while (this.queue.length && Date.now() < end) {
      if (!this.running) this.pump();
      await new Promise((r) => setTimeout(r, 100));
    }
    return this.queue.length === 0;
  }
}

globalThis.Uploader = Uploader;
